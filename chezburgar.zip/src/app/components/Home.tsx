import { useState, useEffect } from 'react';
import {
  Gamepad2, Rocket, Sword, Zap, Trophy, Star, Flame,
  Skull, Sparkles, Crown, Wand2,
  Pizza, Coffee, Music,
  Sun, Moon,
  Cat, Ghost, Rocket as Ufo,
  Plane, CarFront, Search
} from 'lucide-react';

const defaultGames = [
  { name: 'Jet boy', icon: Rocket, url: 'https://stickmanclimb2.github.io/play/jet-boy', color: 'bg-purple-500 hover:bg-purple-600' },
  { name: 'Gladihoppers', icon: Sword, url: 'https://gaming-escape.github.io/public/assets/games/gladihoppers/index.html', color: 'bg-red-500 hover:bg-red-600' },
  { name: 'Polytrack', icon: Zap, url: 'https://polytrackmodded.github.io/', color: 'bg-yellow-500 hover:bg-yellow-600' },
  { name: 'Proxy', icon: Star, url: 'https://bit.ly/4wMi98j/', color: 'bg-blue-500 hover:bg-blue-600' },
  { name: 'Hollow knight', icon: Trophy, url: 'https://ubgone.github.io/Hollow-knight4school/', color: 'bg-green-500 hover:bg-green-600' },
  { name: 'Super smash bros', icon: Gamepad2, url: 'https://mspoi.github.io/seraph/games/supersmashbros/index.html', color: 'bg-pink-500 hover:bg-pink-600' },
  { name: 'Subway Surfers', icon: Flame, url: 'https://gitallgames.github.io/projects/subway-surfers-san-francisco/index.html', color: 'bg-orange-500 hover:bg-orange-600' },
  { name: 'Armed forces', icon: Skull, url: 'https://gaming-escape.github.io/iframe?url=public/assets/games/armed-forces-io/', color: 'bg-gray-700 hover:bg-gray-800' },
  { name: 'Grade melon', icon: Sparkles, url: 'https://chezburgar.github.io/Grade-melon-3/login', color: 'bg-indigo-500 hover:bg-indigo-600' },
  { name: 'Bitlife', icon: Crown, url: 'https://browlu27.github.io/gamessite.github.io/projects/bitlife/index.html', color: 'bg-yellow-600 hover:bg-yellow-700' },
  { name: 'Hollow knight Silksong', icon: Wand2, url: 'https://chezburgar.github.io/hollow-knight-silksong/', color: 'bg-violet-500 hover:bg-violet-600' },
  { name: 'Mario kart', icon: Pizza, url: 'https://mspoi.github.io/seraph/games/mariokartds/index.html', color: 'bg-orange-600 hover:bg-orange-700' },
  { name: 'Crossy Road', icon: Music, url: 'https://classroom8.github.io/crossy-road/', color: 'bg-purple-600 hover:bg-purple-700' },
  { name: 'Ks2', icon: Sun, url: 'https://gaming-escape.github.io/iframe?url=public/assets/games/ks-2-teams/', color: 'bg-yellow-500 hover:bg-yellow-600' },
  { name: 'Youtube shorts', icon: Moon, url: 'https://skipvids.com/shorts', color: 'bg-indigo-800 hover:bg-indigo-900' },
  { name: 'Duck life treasure hunt', icon: Cat, url: 'https://guyotjs.github.io/flash/games/dlth.html', color: 'bg-amber-500 hover:bg-amber-600' },
  { name: 'Slope', icon: Ghost, url: 'https://gamedump.github.io/slope/', color: 'bg-purple-700 hover:bg-purple-800' },
  { name: 'Rocket leauge', icon: Ufo, url: 'https://stickmanclimb2.github.io/play/rocket-soccer-derby', color: 'bg-green-500 hover:bg-green-600' },
  { name: 'Snow rider 3d', icon: Plane, url: 'https://gaming-escape.github.io/iframe?url=public/assets/games/snow-rider-3d/', color: 'bg-sky-600 hover:bg-sky-700' },
  { name: 'Armed Forces', icon: CarFront, url: 'https://gaming-escape.github.io/iframe?url=public/assets/games/armed-forces-io/', color: 'bg-red-600 hover:bg-red-700' },
];

interface CustomGame {
  name: string;
  url: string;
  color: string;
}

export function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [customGames, setCustomGames] = useState<CustomGame[]>([]);

  useEffect(() => {
    loadCustomGames();

    const handleGamesUpdate = () => {
      loadCustomGames();
    };

    window.addEventListener('gamesUpdated', handleGamesUpdate);
    return () => window.removeEventListener('gamesUpdated', handleGamesUpdate);
  }, []);

  const loadCustomGames = () => {
    const stored = localStorage.getItem('customGames');
    if (stored) {
      setCustomGames(JSON.parse(stored));
    }
  };

  const allGames = [...defaultGames, ...customGames.map(g => ({ ...g, icon: Gamepad2 }))];

  const filteredGames = allGames.filter(game =>
    game.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex items-center justify-center p-8">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <p className="text-xl text-purple-200">version 3.0</p>
        </div>

        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-purple-300" size={20} />
            <input
              type="text"
              placeholder="Search games..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg bg-white/10 backdrop-blur-sm border border-purple-300/30 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGames.map((game) => (
            <a
              key={game.name}
              href={game.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`${game.color} rounded-xl p-8 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl cursor-pointer`}
            >
              <div className="flex flex-col items-center text-white">
                <game.icon size={64} className="mb-4" />
                <h2 className="text-xl text-center">{game.name}</h2>
              </div>
            </a>
          ))}
        </div>

        {filteredGames.length === 0 && (
          <div className="text-center mt-8">
            <p className="text-purple-300 text-lg">No games found. Try a different search!</p>
          </div>
        )}

        <div className="mt-12 text-center">
          <p className="text-purple-300 text-sm">
            Click any button to start playing!
          </p>
        </div>
      </div>
    </div>
  );
}
