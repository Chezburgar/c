import { useState, useEffect } from 'react';
import { Gamepad2, ExternalLink } from 'lucide-react';

interface Suggestion {
  id: string;
  gameName: string;
  gameUrl: string;
  submittedAt: string;
}

export function Suggestions() {
  const [gameName, setGameName] = useState('');
  const [gameUrl, setGameUrl] = useState('');
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('gameSuggestions');
    if (stored) {
      setSuggestions(JSON.parse(stored));
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!gameName.trim() || !gameUrl.trim()) return;

    const newSuggestion: Suggestion = {
      id: Date.now().toString(),
      gameName: gameName.trim(),
      gameUrl: gameUrl.trim(),
      submittedAt: new Date().toLocaleDateString(),
    };

    const updatedSuggestions = [newSuggestion, ...suggestions];
    setSuggestions(updatedSuggestions);
    localStorage.setItem('gameSuggestions', JSON.stringify(updatedSuggestions));

    setGameName('');
    setGameUrl('');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="flex items-center justify-center p-8 min-h-[calc(100vh-73px)]">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h2 className="text-4xl text-white mb-4">Suggest a Game</h2>
          <p className="text-purple-200">Think we're missing an awesome game? Let us know!</p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 mb-8 border border-purple-300/30">
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="gameName" className="block text-purple-200 mb-2">
                Game Name
              </label>
              <input
                type="text"
                id="gameName"
                value={gameName}
                onChange={(e) => setGameName(e.target.value)}
                placeholder="Enter the name of the game"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-purple-300/30 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-400"
                required
              />
            </div>

            <div className="mb-6">
              <label htmlFor="gameUrl" className="block text-purple-200 mb-2">
                Game URL
              </label>
              <input
                type="url"
                id="gameUrl"
                value={gameUrl}
                onChange={(e) => setGameUrl(e.target.value)}
                placeholder="https://example.com/game"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-purple-300/30 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-400"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 rounded-lg transition-all transform hover:scale-105"
            >
              Submit Suggestion
            </button>

            {submitted && (
              <div className="mt-4 p-4 bg-green-500/20 border border-green-500/30 rounded-lg text-green-200 text-center">
                Thanks for your suggestion!
              </div>
            )}
          </form>
        </div>

        {suggestions.length > 0 && (
          <div>
            <h3 className="text-2xl text-white mb-6">Recent Suggestions</h3>
            <div className="space-y-4">
              {suggestions.map((suggestion) => (
                <div
                  key={suggestion.id}
                  className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-purple-300/30 hover:bg-white/15 transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <Gamepad2 size={32} className="text-purple-300 flex-shrink-0" />
                      <div className="flex-1">
                        <h4 className="text-white text-lg mb-1">{suggestion.gameName}</h4>
                        <a
                          href={suggestion.gameUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-purple-300 hover:text-purple-200 text-sm flex items-center gap-1 break-all"
                        >
                          {suggestion.gameUrl}
                          <ExternalLink size={14} />
                        </a>
                      </div>
                    </div>
                    <span className="text-purple-400 text-sm flex-shrink-0">
                      {suggestion.submittedAt}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
