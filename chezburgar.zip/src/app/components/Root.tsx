import { Outlet, Link, useLocation } from "react-router";
import { useState, useEffect } from "react";

export function Root() {
  const location = useLocation();
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [keySequence, setKeySequence] = useState('');

  useEffect(() => {
    const unlocked = localStorage.getItem('adminUnlocked') === 'true';
    setAdminUnlocked(unlocked);
  }, []);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      const newSequence = keySequence + e.key;
      setKeySequence(newSequence);

      if (newSequence.includes('081711')) {
        setAdminUnlocked(true);
        localStorage.setItem('adminUnlocked', 'true');
        setKeySequence('');
      }

      if (newSequence.length > 10) {
        setKeySequence(newSequence.slice(-10));
      }
    };

    window.addEventListener('keypress', handleKeyPress);
    return () => window.removeEventListener('keypress', handleKeyPress);
  }, [keySequence]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      <nav className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-3xl text-white tracking-wider hover:scale-105 transition-transform">
              🍔 CHEZBURGER
            </Link>
            <div className="flex gap-4">
              <Link
                to="/"
                className={`px-6 py-2 rounded-lg transition-all ${
                  location.pathname === '/'
                    ? 'bg-purple-500 text-white'
                    : 'bg-white/10 text-purple-200 hover:bg-white/20'
                }`}
              >
                Games
              </Link>
              <Link
                to="/suggestions"
                className={`px-6 py-2 rounded-lg transition-all ${
                  location.pathname === '/suggestions'
                    ? 'bg-purple-500 text-white'
                    : 'bg-white/10 text-purple-200 hover:bg-white/20'
                }`}
              >
                Suggest a Game
              </Link>
              {adminUnlocked && (
                <Link
                  to="/admin"
                  className={`px-6 py-2 rounded-lg transition-all ${
                    location.pathname === '/admin'
                      ? 'bg-purple-500 text-white'
                      : 'bg-white/10 text-purple-200 hover:bg-white/20'
                  }`}
                >
                  🔐 Admin
                </Link>
              )}
            </div>
          </div>
        </div>
      </nav>

      <Outlet />
    </div>
  );
}
