import { useState, useEffect } from 'react';
import { Trash2, Plus, Gamepad2, ExternalLink } from 'lucide-react';

interface Suggestion {
  id: string;
  gameName: string;
  gameUrl: string;
  submittedAt: string;
}

interface Game {
  name: string;
  url: string;
  color: string;
}

const colorOptions = [
  { name: 'Purple', value: 'bg-purple-500 hover:bg-purple-600' },
  { name: 'Red', value: 'bg-red-500 hover:bg-red-600' },
  { name: 'Yellow', value: 'bg-yellow-500 hover:bg-yellow-600' },
  { name: 'Blue', value: 'bg-blue-500 hover:bg-blue-600' },
  { name: 'Green', value: 'bg-green-500 hover:bg-green-600' },
  { name: 'Pink', value: 'bg-pink-500 hover:bg-pink-600' },
  { name: 'Orange', value: 'bg-orange-500 hover:bg-orange-600' },
  { name: 'Indigo', value: 'bg-indigo-500 hover:bg-indigo-600' },
  { name: 'Teal', value: 'bg-teal-500 hover:bg-teal-600' },
  { name: 'Cyan', value: 'bg-cyan-500 hover:bg-cyan-600' },
];

export function Admin() {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [newGameName, setNewGameName] = useState('');
  const [newGameUrl, setNewGameUrl] = useState('');
  const [newGameColor, setNewGameColor] = useState(colorOptions[0].value);
  const [gameAdded, setGameAdded] = useState(false);

  useEffect(() => {
    loadSuggestions();
  }, []);

  const loadSuggestions = () => {
    const stored = localStorage.getItem('gameSuggestions');
    if (stored) {
      setSuggestions(JSON.parse(stored));
    }
  };

  const deleteSuggestion = (id: string) => {
    const updated = suggestions.filter(s => s.id !== id);
    setSuggestions(updated);
    localStorage.setItem('gameSuggestions', JSON.stringify(updated));
  };

  const addGame = (e: React.FormEvent) => {
    e.preventDefault();

    if (!newGameName.trim() || !newGameUrl.trim()) return;

    const customGames = JSON.parse(localStorage.getItem('customGames') || '[]');
    const newGame: Game = {
      name: newGameName.trim(),
      url: newGameUrl.trim(),
      color: newGameColor,
    };

    customGames.push(newGame);
    localStorage.setItem('customGames', JSON.stringify(customGames));

    setNewGameName('');
    setNewGameUrl('');
    setNewGameColor(colorOptions[0].value);
    setGameAdded(true);
    setTimeout(() => setGameAdded(false), 3000);

    window.dispatchEvent(new Event('gamesUpdated'));
  };

  return (
    <div className="p-8 min-h-[calc(100vh-73px)]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl text-white mb-4">🔐 Admin Panel</h2>
          <p className="text-purple-200">Manage games and review suggestions</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl text-white mb-6">Add New Game</h3>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-purple-300/30">
              <form onSubmit={addGame}>
                <div className="mb-4">
                  <label htmlFor="adminGameName" className="block text-purple-200 mb-2">
                    Game Name
                  </label>
                  <input
                    type="text"
                    id="adminGameName"
                    value={newGameName}
                    onChange={(e) => setNewGameName(e.target.value)}
                    placeholder="Enter game name"
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-purple-300/30 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-400"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="adminGameUrl" className="block text-purple-200 mb-2">
                    Game URL
                  </label>
                  <input
                    type="url"
                    id="adminGameUrl"
                    value={newGameUrl}
                    onChange={(e) => setNewGameUrl(e.target.value)}
                    placeholder="https://example.com/game"
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-purple-300/30 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-400"
                    required
                  />
                </div>

                <div className="mb-6">
                  <label htmlFor="adminGameColor" className="block text-purple-200 mb-2">
                    Button Color
                  </label>
                  <select
                    id="adminGameColor"
                    value={newGameColor}
                    onChange={(e) => setNewGameColor(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-purple-300/30 text-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                  >
                    {colorOptions.map((color) => (
                      <option key={color.value} value={color.value} className="bg-gray-800">
                        {color.name}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 rounded-lg transition-all transform hover:scale-105 flex items-center justify-center gap-2"
                >
                  <Plus size={20} />
                  Add Game
                </button>

                {gameAdded && (
                  <div className="mt-4 p-4 bg-green-500/20 border border-green-500/30 rounded-lg text-green-200 text-center">
                    Game added successfully!
                  </div>
                )}
              </form>
            </div>
          </div>

          <div>
            <h3 className="text-2xl text-white mb-6">Review Suggestions</h3>
            <div className="space-y-4 max-h-[600px] overflow-y-auto">
              {suggestions.length === 0 ? (
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-purple-300/30 text-center text-purple-300">
                  No suggestions to review
                </div>
              ) : (
                suggestions.map((suggestion) => (
                  <div
                    key={suggestion.id}
                    className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-purple-300/30 hover:bg-white/15 transition-all"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <Gamepad2 size={24} className="text-purple-300 flex-shrink-0 mt-1" />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-white mb-1">{suggestion.gameName}</h4>
                          <a
                            href={suggestion.gameUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-purple-300 hover:text-purple-200 text-sm flex items-center gap-1 break-all"
                          >
                            <span className="truncate">{suggestion.gameUrl}</span>
                            <ExternalLink size={12} className="flex-shrink-0" />
                          </a>
                          <p className="text-purple-400 text-xs mt-1">{suggestion.submittedAt}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteSuggestion(suggestion.id)}
                        className="bg-red-500/20 hover:bg-red-500/30 text-red-300 p-2 rounded-lg transition-all flex-shrink-0"
                        title="Delete suggestion"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
