import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/Home";
import { Suggestions } from "./components/Suggestions";
import { Admin } from "./components/Admin";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "suggestions", Component: Suggestions },
      { path: "admin", Component: Admin },
    ],
  },
]);
